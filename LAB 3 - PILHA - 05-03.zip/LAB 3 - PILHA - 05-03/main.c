/* Isabella Rubio Venancio - 05-03-2026

 * ============================================================
 *  MackEdit - Mini Editor de Texto com Desfazer/Refazer
 *  Estruturas de Dados I - Universidade Presbiteriana Mackenzie
 * ============================================================
 *  Aluno(s): 
 *
 *  Este programa simula as operacoes basicas de um editor de
 *  texto, usando o TAD Pilha para implementar as funcoes de
 *  desfazer (Ctrl+Z) e refazer (Ctrl+Y).
 *
 *  Pilha "editor":  armazena os caracteres digitados.
 *  Pilha "lixeira": armazena os caracteres desfeitos (para refazer).
 *
 *  TODO: Complete as funcoes marcadas com TODO.
 * ============================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilha.h"

#define TAM_MAXIMO 256

/* ============================================================
 * Funcao: mostrarTexto
 * Descricao: Exibe o conteudo atual do editor.
 *   Como a pilha armazena os caracteres, e temos acesso ao
 *   vetor interno (s->pilha) e ao indice do topo (s->curr_size),
 *   podemos percorrer da base ao topo para exibir na ordem.
 * (Ja implementada - nao precisa modificar)
 * ============================================================ */
void mostrarTexto(Stack *editor) { //ponteiro faz ref a outra funcao 
    if (isEmpty(editor)) { //se a pilha estiver vazia:
        printf("[editor vazio]\n");
        return;
    }
    printf("Texto atual: \"");
    for (int i = 0; i <= editor->curr_size; i++) {
        printf("%c", editor->pilha[i]);
    }
    printf("\"\n");
    printf("(%d caractere(s))\n", sizeElements(editor));
}

/* ============================================================
 * Funcao: digitarTexto
 * Descricao: Recebe uma string e empilha cada caractere no
 *   editor, um por um. Ao digitar texto novo, a lixeira
 *   (pilha de refazer) deve ser esvaziada - assim como
 *   acontece em editores reais quando voce digita algo novo
 *   apos ter feito "desfazer".
 *
 * TODO: Implemente esta funcao.
 *   1. Esvaziar a lixeira (desempilhar tudo dela)
 *   2. Para cada caractere da string recebida, empilhar no editor
 *   3. Se a pilha ficar cheia antes de terminar, avise o usuario
 * ============================================================ */
void digitarTexto(Stack *editor, Stack *lixeira, char *texto) {
    /* TODO: implemente aqui */
    while (!isEmpty(lixeira)) { //esvazia a lixeira 
        pop(lixeira);
    }

    for (int i = 0; texto[i] != '\0'; i++) { //percorre o string 
        if (isFull(editor)) {
            printf("Editor cheio! Nem todo o texto foi inserido.\n");
            return;
        }

        push(editor, texto[i]); //"empilha" os caracteres - comportamento normal de pilha que so coloca e tira no topo da pilha 

    }

}

/* ============================================================
 * Funcao: desfazer
 * Descricao: Remove o ultimo caractere digitado (topo do editor)
 *   e o coloca na lixeira, para possibilitar o "refazer".
 *   Simula o comportamento do Ctrl+Z.
 *
 * TODO: Implemente esta funcao.
 *   1. Verificar se o editor nao esta vazio
 *   2. Desempilhar o caractere do editor
 *   3. Empilhar esse caractere na lixeira
 *   4. Exibir qual caractere foi desfeito
 * ============================================================ */
void desfazer(Stack *editor, Stack *lixeira) {
    /* TODO: implemente aqui */
    if (isEmpty(editor)) {
        printf("Nada para desfazer.\n"); //se estiver vazio ja 
        return;
    }

    char c = pop(editor); //tira o caracter do topo 
    push(lixeira, c); //e coloca esse caracter na lixeira 

    printf("Desfeito: %c\n", c); //mostra qual caracter foi desfeito - tirado da pilha do editor 
}


/* ============================================================
 * Funcao: refazer
 * Descricao: Recupera o ultimo caractere desfeito (topo da lixeira)
 *   e o coloca de volta no editor.
 *   Simula o comportamento do Ctrl+Y.
 *
 * TODO: Implemente esta funcao.
 *   1. Verificar se a lixeira nao esta vazia
 *   2. Desempilhar o caractere da lixeira
 *   3. Empilhar esse caractere no editor
 *   4. Exibir qual caractere foi refeito
 * ============================================================ */
void refazer(Stack *editor, Stack *lixeira) {  //oposto do desfazer 
    /* TODO: implemente aqui */
     if (isEmpty(lixeira)) {
        printf("Nada para refazer.\n");
        return;
    }

    char c = pop(lixeira); //tira o caracter da lixeira e coloca de volta no editor - "desfaz o desfazer"
    push(editor, c);

    printf("Refeito: %c\n", c);
}


/* ============================================================
 * Funcao: desfazerTudo
 * Descricao: Desfaz TODOS os caracteres do editor, movendo
 *   cada um para a lixeira. Equivale a pressionar Ctrl+Z
 *   repetidamente ate esvaziar o editor.
 *
 * TODO: Implemente esta funcao.
 *   1. Enquanto o editor nao estiver vazio, mover cada
 *      caractere do editor para a lixeira
 *   2. Ao final, informar quantos caracteres foram desfeitos
 * ============================================================ */
void desfazerTudo(Stack *editor, Stack *lixeira) {
    /* TODO: implemente aqui */
    int contador = 0;

    while (!isEmpty(editor)) { //enquanto o editor nao estiver vazio 

        char c = pop(editor); //tira tudo do editor 
        push(lixeira, c); //coloca tudo que estava no editar na lixeira 
        contador++; //soma no contador a quantidade de caracateres movidos 
    }

    printf("%d caractere(s) desfeito(s).\n", contador);
}


/* ============================================================
 * Funcao: mostrarStatus
 * Descricao: Exibe informacoes sobre o estado atual do editor:
 *   - Texto atual
 *   - Quantidade de caracteres no editor
 *   - Quantidade de caracteres na lixeira (disponiveis p/ refazer)
 *   - Capacidade maxima
 *
 * TODO: Implemente esta funcao.
 * ============================================================ */
void mostrarStatus(Stack *editor, Stack *lixeira) {
    /* TODO: implemente aqui */
     printf("\n----- STATUS DO EDITOR -----\n");

    mostrarTexto(editor);

    printf("Caracteres no editor: %d\n", sizeElements(editor)); //mostra o tamanho do vetor/tamanho da pilha
    printf("Disponiveis para refazer: %d\n", sizeElements(lixeira)); //tamanho do vetor lixeira 
    printf("Capacidade maxima: %d\n", TAM_MAXIMO); 
}


/* ============================================================
 *  MENU PRINCIPAL
 *  (Ja implementado - nao precisa modificar)
 * ============================================================ */
int main() {
    Stack *editor  = CriaStack(TAM_MAXIMO); //cria uma pilha de tamanho maximo 
    Stack *lixeira = CriaStack(TAM_MAXIMO);

    int opcao;
    char buffer[TAM_MAXIMO];

    printf("========================================\n");
    printf("  MackEdit - Mini Editor de Texto\n");
    printf("  Ctrl+Z e Ctrl+Y com Pilhas!\n");
    printf("========================================\n\n");

    do {
        printf("\n--- MENU ---\n");
        printf("[1] Digitar texto\n");
        printf("[2] Desfazer (Ctrl+Z)\n");
        printf("[3] Refazer (Ctrl+Y)\n");
        printf("[4] Desfazer tudo\n");
        printf("[5] Mostrar texto\n");
        printf("[6] Status do editor\n");
        printf("[0] Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);
        getchar(); /* consumir o \n do scanf */

        switch (opcao) {
            case 1:
                printf("Digite o texto: ");
                fgets(buffer, TAM_MAXIMO, stdin);
                /* Remove o \n que o fgets captura */
                buffer[strcspn(buffer, "\n")] = '\0';
                digitarTexto(editor, lixeira, buffer);
                mostrarTexto(editor);
                break;

            case 2:
                desfazer(editor, lixeira);
                mostrarTexto(editor);
                break;

            case 3:
                refazer(editor, lixeira);
                mostrarTexto(editor);
                break;

            case 4:
                desfazerTudo(editor, lixeira);
                break;

            case 5:
                mostrarTexto(editor);
                break;

            case 6:
                mostrarStatus(editor, lixeira);
                break;

            case 0:
                printf("\nTexto final: ");
                mostrarTexto(editor);
                printf("Saindo do MackEdit. Ate mais!\n");
                break;

            default:
                printf("Opcao invalida!\n");
        }

    } while (opcao != 0);

    DestroiStack(editor);
    DestroiStack(lixeira);

    return 0;
}
