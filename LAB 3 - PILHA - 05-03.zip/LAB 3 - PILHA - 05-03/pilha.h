//.h HEADER = possui a declaração das funções mas elas ainda nao foram implementadas + o struct da pilha 

typedef struct Pilha {
    char *pilha; /* um ponteiro que alocaremos um vetor durante a execução */
    int curr_size; /* o tamanho atual da pilha, defini que pilha vazia é -1 */
    int max_size; /* o tamanho máximo da pilha, que será definido em tempo de execução */
} Stack;


Stack* CriaStack(int tamanho);

int isEmpty(Stack *s);

int isFull(Stack *s);

char topo(Stack *s);

int sizeElements(Stack *s);

int push(Stack *s, char elemento);

char pop(Stack *s);

void DestroiStack(Stack *s);