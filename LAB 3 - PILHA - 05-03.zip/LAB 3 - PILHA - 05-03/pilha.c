#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

Stack* CriaStack(int tamanho) {
    Stack *aux; /* começo com um ponteiro, que será o retorno */
    aux = malloc(sizeof(Stack)); /* aloco a estrutura */
    aux->pilha = malloc(sizeof(char)*tamanho); /* aloco o vetor pilha */
    aux->curr_size = -1; /* tamanho default da pilha vazia: -1 */
    aux->max_size = tamanho; /* tamanho máximo: o recebido como parâmetro */
    return aux;
}

void DestroiStack(Stack *s) {
    free(s->pilha);
    free(s);
}

int isEmpty(Stack *s) {
    if (s->curr_size == -1)
        return 1;
    return 0;
}

int isFull(Stack *s) {
    if (s->curr_size+1 == s->max_size)
        return 1;
    return 0;
}


char topo(Stack *s) {
    char retorno = '\0';
    if (isEmpty(s)) {
        printf("Pilha vazia!");
    } else {
        retorno = s->pilha[s->curr_size];
    }
    return retorno;
}

int sizeElements(Stack *s) {
    return s->curr_size + 1;
}

/* coloquei um retorno so pra indicar o sucesso
   da operação:
       -0 indica que não foi possível adicionar
       -1 indica que foi adicionado com sucesso */
int push(Stack *s, char elemento) {
    if (isFull(s)) {
        printf("Elemento %d não adicionado. Motivo: pilha cheia!\n", elemento);
        return 0;
    }
    s->curr_size++;
    s->pilha[s->curr_size] = elemento;
    return 1;
}

char pop(Stack *s) {
    /* pede para topo mostrar o elemento que será removido */
    char elementoRemovido = topo(s);
    /* se de fato a pilha não está vazia (elemento não é "")
        então vamos decrementar seu tamanho */
    if (elementoRemovido != '\0')
        s->curr_size--;
    return elementoRemovido;
}